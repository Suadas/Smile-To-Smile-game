package com.example.suada.smiletosmile;

import static org.junit.Assert.*;

/**
 * Created by suada on 01.11.2016..
 */
public class MainActivityTest {

}